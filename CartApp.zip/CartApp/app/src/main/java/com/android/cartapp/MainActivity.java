package com.android.cartapp;

import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import android.content.Intent;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
//import android.view.Menu;
//import android.view.MenuInflater;
//import android.view.MenuItem;


public class MainActivity extends Activity {

    final Context context = this;
    private Button button;
    public String tuser="let";
    public String tpass="pass";
    EditText user; EditText pass;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.btnEnter);


        // add button listener
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

            // get prompts.xml view
            LayoutInflater li = LayoutInflater.from(context);
            View promptsView = li.inflate(R.layout.login, null);

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                    context, R.style.AlertDialogTheme);

            alertDialogBuilder.setView(promptsView);  // set login.xml in promptsView

            final EditText userInput = (EditText) promptsView .findViewById(R.id.user);
            final EditText passInput = (EditText) promptsView .findViewById(R.id.pass);

                AlertDialog.Builder builder = alertDialogBuilder // set dialog message
                        .setCancelable(true)
                        .setPositiveButton("OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //result.setText(userInput.getText()); // get user input
                                        String ttuser = userInput.getText().toString();
                                        String ttpass = ttuser+passInput.getText().toString();
                                        if (ttpass.equals("me123")) {
                                            Intent intent = new Intent(MainActivity.this, HomePage.class);
                                            startActivity(intent);
                                            //startActivity(new Intent("HomePage"));
                                        }
                                    }
                                })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });
                AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show(); // show it

            }
        });
    }
}