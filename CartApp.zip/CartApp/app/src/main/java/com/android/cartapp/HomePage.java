package com.android.cartapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.text.Layout;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


public class HomePage extends Activity {
    public Float tots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Set up popup menu
        View viewContext = findViewById(R.id.hmenu); //get button id from xml
        registerForContextMenu(viewContext);
    }

    public void doLogout(View v) {
        finish(); //calls onDestroy method
    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        //TODO Auto-generated method stub
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    private void showToast(String str){
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.layout_cart,
                (ViewGroup) findViewById(R.id.toast_layout_root));
        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        //TODO Auto-generated method stub
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.layout_cart,
                (ViewGroup) findViewById(R.id.toast_layout_root));
        switch(item.getItemId()){
            case R.id.cart:   //from context_menu.xml id
                tots = 0.00f;
                RelativeLayout prod1 = (RelativeLayout) layout.findViewById(R.id.prod1);
                RelativeLayout prod2 = (RelativeLayout) layout.findViewById(R.id.prod2);
                RelativeLayout prod3 = (RelativeLayout) layout.findViewById(R.id.prod3);
                RelativeLayout prod4 = (RelativeLayout) layout.findViewById(R.id.prod4);
                RelativeLayout prod5 = (RelativeLayout) layout.findViewById(R.id.prod5);
                RelativeLayout prod6 = (RelativeLayout) layout.findViewById(R.id.prod6);
                RelativeLayout prod7 = (RelativeLayout) layout.findViewById(R.id.prod7);
                RelativeLayout prod8 = (RelativeLayout) layout.findViewById(R.id.prod8);
                RelativeLayout prod9 = (RelativeLayout) layout.findViewById(R.id.prod9);

                CheckBox ck1 = (CheckBox) findViewById(R.id.ck1);
                CheckBox ck2 = (CheckBox) findViewById(R.id.ck2);
                CheckBox ck3 = (CheckBox) findViewById(R.id.ck3);
                CheckBox ck4 = (CheckBox) findViewById(R.id.ck4);
                CheckBox ck5 = (CheckBox) findViewById(R.id.ck5);
                CheckBox ck6 = (CheckBox) findViewById(R.id.ck6);
                CheckBox ck7 = (CheckBox) findViewById(R.id.ck7);
                CheckBox ck8 = (CheckBox) findViewById(R.id.ck8);
                CheckBox ck9 = (CheckBox) findViewById(R.id.ck9);
                Float cck1 = Float.parseFloat(ck1.getText().toString());
                Float cck2 = Float.parseFloat(ck2.getText().toString());
                Float cck3 = Float.parseFloat(ck3.getText().toString());
                Float cck4 = Float.parseFloat(ck4.getText().toString());
                Float cck5 = Float.parseFloat(ck5.getText().toString());
                Float cck6 = Float.parseFloat(ck6.getText().toString());
                Float cck7 = Float.parseFloat(ck7.getText().toString());
                Float cck8 = Float.parseFloat(ck8.getText().toString());
                Float cck9 = Float.parseFloat(ck9.getText().toString());

                if (ck1.isChecked()) { tots += cck1; } else { prod1.setVisibility(View.GONE); }
                if (ck2.isChecked()) { tots += cck2; } else { prod2.setVisibility(View.GONE); }
                if (ck3.isChecked()) { tots += cck3; } else { prod3.setVisibility(View.GONE); }
                if (ck4.isChecked()) { tots += cck4; } else { prod4.setVisibility(View.GONE); }
                if (ck5.isChecked()) { tots += cck5; } else { prod5.setVisibility(View.GONE); }
                if (ck6.isChecked()) { tots += cck6; } else { prod6.setVisibility(View.GONE); }
                if (ck7.isChecked()) { tots += cck7; } else { prod7.setVisibility(View.GONE); }
                if (ck8.isChecked()) { tots += cck8; } else { prod8.setVisibility(View.GONE); }
                if (ck9.isChecked()) { tots += cck9; } else { prod9.setVisibility(View.GONE); }

                if (tots!=0.0) {
                    TextView cartsum = (TextView) layout.findViewById(R.id.cartsum); //layout define 2lines ato
                    cartsum.setText(""+tots);
                    Toast toast = new Toast(getApplicationContext());
                    toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
                    toast.setDuration(Toast.LENGTH_LONG);
                    toast.setView(layout);
                    toast.show();
                }
                return true;

            case R.id.about:
                View view = inflater.inflate(R.layout.toast_about, //toast xml
                        (ViewGroup) findViewById(R.id.relativeLayout1));
                Toast toast = new Toast(this);
                toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
                toast.setView(view); //the view define 2 lines atop
                toast.show();
                return true;

            case R.id.logout:
                finish();
            default:
                return super.onContextItemSelected(item);
        }
    }

}
