package com.android.crud;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Context;

import android.widget.TextView;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void doViewList(View v) {
        Intent intent = new Intent(this, ViewListActivity.class);
        startActivity(intent);
    }

    public void doAddRec(View v) {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }

    public void doViewRec(View v) {
        int intVal=0;
        EditText searchid = (EditText) findViewById(R.id.searchID);
        try
        { if(searchid.toString() != null)
            intVal = Integer.parseInt(searchid.getText().toString()); }
        catch (NumberFormatException e)
        { intVal = 0; }
        if (intVal < 1) { doError("There is no record.");
        } else {
        Intent intent = new Intent(this, ViewActivity.class);
        intent.putExtra("id", searchid.getText().toString());
        startActivity(intent); }
    }

    public void doEditRec(View v) {
        int intVal=0;
        EditText searchid = (EditText) findViewById(R.id.searchID);
        try
        { if(searchid.toString() != null)
                intVal = Integer.parseInt(searchid.getText().toString()); }
            catch (NumberFormatException e)
        { intVal = 0; }

        if (intVal < 1) { doError("There is no record.");
        } else {
            Intent intent = new Intent(this, EditActivity.class);
            intent.putExtra("id", searchid.getText().toString());
            startActivity(intent); }
    }

    public void doDeleteRec(View v) {
        int intVal=0;
        EditText searchid = (EditText) findViewById(R.id.searchID);
        try
        { if(searchid.toString() != null)
            intVal = Integer.parseInt(searchid.getText().toString()); }
        catch (NumberFormatException e)
        { intVal = 0; }

        if (intVal < 1) { doError("There is no record.");
        } else {
            Intent intent = new Intent(this, DeleteActivity.class);
            intent.putExtra("id", searchid.getText().toString());
            startActivity(intent); }
    }

    public void doAbout(View v){
        int duration = Toast.LENGTH_LONG;
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.toast_about, //toast xml
                (ViewGroup) findViewById(R.id.relativeLayout1));

        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.setView(view);
        toast.show();
    }

    public void doError(String message){
       View view = getLayoutInflater().inflate(R.layout.toast_error,
               (ViewGroup) findViewById(R.id.ErrorLayout));

        TextView text = (TextView) view.findViewById(R.id.textError);
        text.setText(message);

        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.setView(view);
        toast.show();
    }
}
