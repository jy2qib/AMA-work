package com.android.crud;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ViewActivity extends Activity {
    DatabaseHelper studentDB;
    TextView textid, txtName, txtCourse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_view);
        studentDB = new DatabaseHelper(this);

        Cursor res = studentDB.getAllData();

        textid = (TextView) findViewById(R.id.textID);
        txtName = (TextView) findViewById(R.id.editText_name);
        txtCourse = (TextView) findViewById(R.id.editText_course);

        Intent intent = getIntent();
        String ide = intent.getStringExtra("id"); //see strings.xml
        textid.setText(ide);


        boolean fawnd=false;
        while (res.moveToNext()) {
            int intVal = Integer.parseInt(res.getString(0));
            if (intVal == Integer.parseInt(ide)) {
                txtName.setText(res.getString(2)+", "+res.getString(1));
                txtCourse.setText(res.getString(3));
                fawnd = true;
                break;
            }
        }
        if (!fawnd) {
            doMessage("VIEW ID not found.");
            finish(); }
    }

    public void doAbout(View v){
        int duration = Toast.LENGTH_LONG;
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.toast_about, //toast xml
                (ViewGroup) findViewById(R.id.relativeLayout1));

        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.setView(view);
        toast.show();
    }

    public void doMessage(String message){
        View view = getLayoutInflater().inflate(R.layout.toast_error,
                (ViewGroup) findViewById(R.id.ErrorLayout));

        TextView text = (TextView) view.findViewById(R.id.textError);
        text.setText(message);

        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.setView(view);
        toast.show();
    }

    public void doBack(View v) {
        finish(); //calls onDestroy method
    }
}