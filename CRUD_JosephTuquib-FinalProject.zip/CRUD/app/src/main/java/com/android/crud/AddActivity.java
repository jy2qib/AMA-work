package com.android.crud;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class AddActivity extends Activity {
    DatabaseHelper studentDB;
    EditText editFname, editLname, editCourse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_add);

        studentDB = new DatabaseHelper(this);

        editFname = (EditText) findViewById(R.id.editText_fname);
        editLname = (EditText) findViewById(R.id.editText_lname);
        editCourse = (EditText) findViewById(R.id.editText_course);
    }

    public void doAddRec(View v) {
        //Check first if all field has entry
        int lfname = editFname.getText().toString().trim().length();
        int llname = editLname.getText().toString().trim().length();
        int lcourse = editCourse.getText().toString().trim().length();

        //check if for empty fields
        if (lfname==0 || llname==0 || lcourse==0) { doMessage("Data is incomplete."); }
        else {
            boolean isAdded = studentDB.insertData(editFname.getText().toString(),
                    editLname.getText().toString(),
                    editCourse.getText().toString().toUpperCase());

            String studname = (editFname.getText().toString())+" "+(editLname.getText().toString());
            if (isAdded) {
                doMessage(studname+" has been added"); }
            else {
                doMessage("No record added. Try Again."); }
            finish();
        }
    }

    public void doAbout(View v){
        int duration = Toast.LENGTH_LONG;
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.toast_about, //toast xml
                (ViewGroup) findViewById(R.id.relativeLayout1));

        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.setView(view);
        toast.show();
    }

    public void doMessage(String message){
        View view = getLayoutInflater().inflate(R.layout.toast_error,
                (ViewGroup) findViewById(R.id.ErrorLayout));

        TextView text = (TextView) view.findViewById(R.id.textError);
        text.setText(message);

        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.setView(view);
        toast.show();
    }

    public void doBack(View v) {
        finish(); //calls onDestroy method
    }

}