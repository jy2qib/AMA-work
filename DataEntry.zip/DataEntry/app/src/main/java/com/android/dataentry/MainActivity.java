package com.android.dataentry;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class MainActivity extends Activity {

    Context context;
    CharSequence text;
    int duration;
    Toast toast;

    String radio_button ="Male";
    String rating_bar = "3.0";
    String spinner_val = "";
    String person_txt = "None";
    String address_txt = "None";
    String contact_txt = "None";
    Spinner spinner;

    boolean fruit = false;
    boolean meat = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);

        setContentView(R.layout.activity_main);

        getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.window_title);

        //Toast ---------------------------------------------------------------- >>
        context = getApplicationContext();
        duration = Toast.LENGTH_LONG;


        //Spinner ---------------------------------------------------------------- >>
        spinner = (Spinner) findViewById(R.id.spinner);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.spinner_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(1); //set default  BSCS

        //RatingBar ---------------------------------------------------------------- >>
        RatingBar ratingBar = (RatingBar) findViewById(R.id.rbar_star);
        ratingBar.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                // TODO Auto-generated method stub
                rating_bar = String.valueOf(rating);
            }
        });
    }

    public void doRadioButton(View v){
        boolean checked = ((RadioButton)v).isChecked();
        switch(v.getId()){
            case R.id.rad_one:
                radio_button = "Male";
                break;
            case R.id.rad_two:
                radio_button = "Female";
                break;
        }
    }

    public void doAbout(View v){
        duration = Toast.LENGTH_LONG;
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.toast_about, //toast xml
                (ViewGroup) findViewById(R.id.relativeLayout1));

        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL, 0, 0);
        toast.setView(view);
        toast.show();
    }

    public void doButton(View v){
        String ttext;
        spinner_val = spinner.getSelectedItem().toString();
        EditText person_name = (EditText) findViewById(R.id.person_name);
        EditText address = (EditText) findViewById(R.id.address);
        EditText contact = (EditText) findViewById(R.id.contact);
        person_txt = person_name.getText().toString();
        person_txt = person_name.getText().toString();
        address_txt = address.getText().toString();
        contact_txt = contact.getText().toString();
        ttext = person_txt + "\n";
        ttext = ttext.toString() + radio_button + "\n";
        ttext = ttext.toString() + spinner_val + "\n";
        ttext = ttext.toString() + address_txt + "\n";
        ttext = ttext.toString() + contact_txt + "\n";
        ttext = ttext.toString() + rating_bar;


        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.toast_main,  //toast xml
                (ViewGroup) findViewById(R.id.custom_toast_container));

        TextView text = (TextView) layout.findViewById(R.id.text);
        text.setText(ttext);

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }

}
